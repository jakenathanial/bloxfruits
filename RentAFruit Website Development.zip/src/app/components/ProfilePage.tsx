import { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { apiCall } from '../../utils/supabase-client';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { User, Ship, Save } from 'lucide-react';
import { motion } from 'motion/react';

export function ProfilePage() {
  const { user, refreshUser } = useAuth();
  const [name, setName] = useState('');
  const [hasFastBoat, setHasFastBoat] = useState(false);
  const [hasBeastHunterBoat, setHasBeastHunterBoat] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setHasFastBoat(user.hasFastBoat || false);
      setHasBeastHunterBoat(user.hasBeastHunterBoat || false);
    }
  }, [user]);

  const saveProfile = async () => {
    if (!user) return;

    setSaving(true);
    try {
      await apiCall('/profile', {
        method: 'PUT',
        body: JSON.stringify({
          name,
          hasFastBoat,
          hasBeastHunterBoat,
        }),
      });
      await refreshUser();
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Failed to update profile:', error);
      alert('Failed to update profile. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black pt-24 pb-8 px-4 flex items-center justify-center">
        <div className="text-center">
          <User className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">Please login to view your profile</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black pt-24 pb-8 px-4">
      <div className="container mx-auto max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-gray-900/90 to-black/90 backdrop-blur-sm border border-purple-500/30 rounded-2xl p-8"
        >
          <div className="flex items-center gap-4 mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Your Profile
              </h1>
              <p className="text-gray-400">{user.email}</p>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <Label htmlFor="name" className="text-gray-300 mb-2 block">
                Display Name
              </Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your display name"
                className="bg-gray-800/50 border-gray-700 text-white"
              />
            </div>

            <div className="bg-blue-900/30 border border-blue-500/50 rounded-lg p-6 space-y-4">
              <div className="flex items-center gap-3 mb-4">
                <Ship className="w-6 h-6 text-blue-400" />
                <h3 className="text-lg font-semibold text-white">Boat Ownership</h3>
              </div>

              <div className="flex items-center justify-between bg-gray-800/50 rounded-lg p-4">
                <div>
                  <Label htmlFor="fastBoat" className="text-white font-medium">
                    Fast Boat
                  </Label>
                  <p className="text-sm text-gray-400">I own a Fast Boat in Blox Fruits</p>
                </div>
                <Switch
                  id="fastBoat"
                  checked={hasFastBoat}
                  onCheckedChange={setHasFastBoat}
                />
              </div>

              <div className="flex items-center justify-between bg-gray-800/50 rounded-lg p-4">
                <div>
                  <Label htmlFor="beastHunter" className="text-white font-medium">
                    Beast Hunter Boat
                  </Label>
                  <p className="text-sm text-gray-400">I own a Beast Hunter Boat (Required for hunts)</p>
                </div>
                <Switch
                  id="beastHunter"
                  checked={hasBeastHunterBoat}
                  onCheckedChange={setHasBeastHunterBoat}
                />
              </div>
            </div>

            <Button
              onClick={saveProfile}
              disabled={saving}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-6 transition-all duration-300 hover:scale-105"
            >
              <Save className="w-5 h-5 mr-2" />
              {saving ? 'Saving...' : 'Save Profile'}
            </Button>
          </div>

          <div className="mt-8 pt-6 border-t border-gray-700">
            <h3 className="text-sm font-semibold text-gray-400 mb-2">Account Information</h3>
            <div className="space-y-1 text-sm text-gray-500">
              <p>User ID: {user.id}</p>
              <p>Account created: {new Date().toLocaleDateString()}</p>
              {user.isAdmin && (
                <p className="text-purple-400 font-semibold">Admin Account</p>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
