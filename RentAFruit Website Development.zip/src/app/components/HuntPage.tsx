import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { apiCall } from '../../utils/supabase-client';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { ArrowLeft, Plus, Users, Clock, Ship, AlertCircle, Send } from 'lucide-react';
import { LoginModal } from './LoginModal';

interface Room {
  id: string;
  destination: string;
  hostName: string;
  players: Array<{
    userId: string;
    userName: string;
    robloxUsername: string;
    hasFastBoat: boolean;
    hasBeastHunterBoat: boolean;
  }>;
  maxPlayers: number;
  createdAt: string;
  expiresAt: string;
}

interface Message {
  id: string;
  userName: string;
  message: string;
  createdAt: string;
}

export function HuntPage() {
  const { user } = useAuth();
  const [selectedDestination, setSelectedDestination] = useState<string | null>(null);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [robloxUsername, setRobloxUsername] = useState('');
  const [chatMessages, setChatMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    if (selectedDestination) {
      fetchRooms();
      const interval = setInterval(fetchRooms, 5000);
      return () => clearInterval(interval);
    }
  }, [selectedDestination]);

  useEffect(() => {
    if (selectedRoom) {
      fetchMessages();
      fetchRoomDetails();
      const interval = setInterval(() => {
        fetchMessages();
        fetchRoomDetails();
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [selectedRoom]);

  const fetchRooms = async () => {
    if (!selectedDestination) return;
    try {
      const { rooms: fetchedRooms } = await apiCall(`/rooms?destination=${selectedDestination}`);
      setRooms(fetchedRooms);
    } catch (error) {
      console.error('Failed to fetch rooms:', error);
    }
  };

  const fetchRoomDetails = async () => {
    if (!selectedRoom) return;
    try {
      const { room } = await apiCall(`/rooms/${selectedRoom.id}`);
      setSelectedRoom(room);
    } catch (error) {
      console.error('Failed to fetch room details:', error);
      setSelectedRoom(null);
    }
  };

  const fetchMessages = async () => {
    if (!selectedRoom) return;
    try {
      const { messages } = await apiCall(`/rooms/${selectedRoom.id}/messages`);
      setChatMessages(messages);
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    }
  };

  const createRoom = async () => {
    if (!user) {
      setShowLoginModal(true);
      return;
    }
    if (!robloxUsername.trim()) {
      alert('Please enter your Roblox username');
      return;
    }

    try {
      const { room } = await apiCall('/rooms', {
        method: 'POST',
        body: JSON.stringify({
          destination: selectedDestination,
          robloxUsername,
          maxPlayers: 7,
        }),
      });
      setShowCreateModal(false);
      setRobloxUsername('');
      fetchRooms();
      setSelectedRoom(room);
    } catch (error) {
      console.error('Failed to create room:', error);
      alert('Failed to create room. Please try again.');
    }
  };

  const joinRoom = async (roomId: string) => {
    if (!user) {
      setShowLoginModal(true);
      return;
    }
    if (!robloxUsername.trim()) {
      const username = prompt('Enter your Roblox username:');
      if (!username) return;
      setRobloxUsername(username);

      try {
        const { room } = await apiCall(`/rooms/${roomId}/join`, {
          method: 'POST',
          body: JSON.stringify({ robloxUsername: username }),
        });
        fetchRooms();
        setSelectedRoom(room);
      } catch (error: any) {
        console.error('Failed to join room:', error);
        alert(error.message || 'Failed to join room. Please try again.');
      }
      return;
    }

    try {
      const { room } = await apiCall(`/rooms/${roomId}/join`, {
        method: 'POST',
        body: JSON.stringify({ robloxUsername }),
      });
      fetchRooms();
      setSelectedRoom(room);
    } catch (error: any) {
      console.error('Failed to join room:', error);
      alert(error.message || 'Failed to join room. Please try again.');
    }
  };

  const leaveRoom = async () => {
    if (!selectedRoom) return;
    try {
      await apiCall(`/rooms/${selectedRoom.id}/leave`, { method: 'POST' });
      setSelectedRoom(null);
      fetchRooms();
    } catch (error) {
      console.error('Failed to leave room:', error);
    }
  };

  const sendMessage = async () => {
    if (!user) {
      setShowLoginModal(true);
      return;
    }
    if (!selectedRoom || !newMessage.trim()) return;

    try {
      await apiCall(`/rooms/${selectedRoom.id}/messages`, {
        method: 'POST',
        body: JSON.stringify({ message: newMessage }),
      });
      setNewMessage('');
      fetchMessages();
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const getTimeRemaining = (expiresAt: string) => {
    const remaining = new Date(expiresAt).getTime() - Date.now();
    const minutes = Math.floor(remaining / 60000);
    return minutes > 0 ? `${minutes} min` : 'Expired';
  };

  const hasBeastHunter = (room: Room) => room.players.some((p) => p.hasBeastHunterBoat);

  if (!selectedDestination) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black pt-24 pb-8 px-4">
        <div className="container mx-auto max-w-5xl">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-center mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
          >
            Destination of Leviathan Heart
          </motion.h1>
          <p className="text-center text-gray-400 mb-12">Choose your hunting destination</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
              onClick={() => setSelectedDestination('Tiki Outpost')}
              className="bg-gradient-to-br from-blue-900/60 to-blue-700/40 backdrop-blur-sm border-2 border-blue-500/50 rounded-2xl p-8 cursor-pointer hover:border-blue-500 hover:scale-105 transition-all duration-300"
            >
              <div className="text-6xl mb-4 text-center">🗿</div>
              <h2 className="text-3xl font-bold text-white text-center mb-2">Tiki Outpost</h2>
              <p className="text-blue-200 text-center">Ancient island surrounded by mystical waters</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              onClick={() => setSelectedDestination('Hydra Island')}
              className="bg-gradient-to-br from-purple-900/60 to-purple-700/40 backdrop-blur-sm border-2 border-purple-500/50 rounded-2xl p-8 cursor-pointer hover:border-purple-500 hover:scale-105 transition-all duration-300"
            >
              <div className="text-6xl mb-4 text-center">🐉</div>
              <h2 className="text-3xl font-bold text-white text-center mb-2">Hydra Island</h2>
              <p className="text-purple-200 text-center">Legendary home of the sea serpents</p>
            </motion.div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black pt-24 pb-8 px-4">
      <div className="container mx-auto max-w-7xl">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => {
                setSelectedDestination(null);
                setSelectedRoom(null);
              }}
              variant="ghost"
              className="text-gray-400 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              {selectedDestination}
            </h1>
          </div>
          <Button
            onClick={() => user ? setShowCreateModal(true) : setShowLoginModal(true)}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold transition-all duration-300 hover:scale-105"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Room
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map((room) => {
            const beastHunter = hasBeastHunter(room);
            return (
              <motion.div
                key={room.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-gradient-to-br from-gray-900/90 to-black/90 backdrop-blur-sm border border-blue-500/30 rounded-xl p-5 hover:border-blue-500/60 transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-4">
                  <span className="text-white font-semibold">{room.hostName}'s Room</span>
                  <div className="flex items-center gap-1 text-sm text-gray-400">
                    <Clock className="w-4 h-4" />
                    {getTimeRemaining(room.expiresAt)}
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4 text-blue-400" />
                    <span className="text-gray-300">
                      {room.players.length} / {room.maxPlayers} Players
                    </span>
                  </div>
                  <div className={`flex items-center gap-2 text-sm ${beastHunter ? 'text-green-400' : 'text-red-400'}`}>
                    <Ship className="w-4 h-4" />
                    <span>{beastHunter ? 'Beast Hunter ✓' : 'No Beast Hunter'}</span>
                  </div>
                  {room.players.some((p) => p.hasFastBoat) && (
                    <div className="flex items-center gap-2 text-sm text-yellow-400">
                      <Ship className="w-4 h-4" />
                      <span>Fast Boat ✓</span>
                    </div>
                  )}
                </div>

                {!beastHunter && (
                  <div className="bg-red-900/30 border border-red-500/50 rounded-lg p-2 mb-3 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <span className="text-xs text-red-300">Beast Hunter Boat required!</span>
                  </div>
                )}

                <Button
                  onClick={() => joinRoom(room.id)}
                  disabled={room.players.length >= room.maxPlayers}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {room.players.length >= room.maxPlayers ? 'Room Full' : 'Join Room'}
                </Button>
              </motion.div>
            );
          })}
        </div>

        {rooms.length === 0 && (
          <div className="text-center text-gray-500 py-12">
            No active rooms. Create the first one!
          </div>
        )}
      </div>

      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="bg-black/95 border-blue-500/50 text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Create Hunt Room
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Roblox Username</label>
              <Input
                value={robloxUsername}
                onChange={(e) => setRobloxUsername(e.target.value)}
                placeholder="Enter your Roblox username"
                className="bg-gray-800/50 border-gray-700 text-white"
              />
            </div>

            <div className="bg-blue-900/30 border border-blue-500/50 rounded-lg p-3">
              <p className="text-sm text-blue-300">
                Room will automatically close after 1 hour or when empty.
              </p>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => setShowCreateModal(false)}
                variant="outline"
                className="flex-1 border-gray-600 text-gray-400 hover:bg-gray-800"
              >
                Cancel
              </Button>
              <Button
                onClick={createRoom}
                className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
              >
                Create Room
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!selectedRoom} onOpenChange={() => setSelectedRoom(null)}>
        <DialogContent className="bg-black/95 border-blue-500/50 text-white max-w-2xl max-h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">
              {selectedRoom?.hostName}'s Hunt Room
            </DialogTitle>
          </DialogHeader>

          {selectedRoom && (
            <>
              <div className="bg-gray-800/50 rounded-lg p-4 mb-4">
                <h3 className="font-semibold mb-3 text-blue-400">Players ({selectedRoom.players.length}/{selectedRoom.maxPlayers})</h3>
                <div className="space-y-2">
                  {selectedRoom.players.map((player) => (
                    <div key={player.userId} className="flex items-center justify-between bg-gray-900/50 rounded p-2">
                      <div>
                        <div className="font-semibold">{player.userName}</div>
                        <div className="text-sm text-gray-400">{player.robloxUsername}</div>
                      </div>
                      <div className="flex gap-2">
                        {player.hasBeastHunterBoat && (
                          <span className="text-xs bg-green-600 px-2 py-1 rounded">Beast Hunter</span>
                        )}
                        {player.hasFastBoat && (
                          <span className="text-xs bg-yellow-600 px-2 py-1 rounded">Fast Boat</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-3 mb-4 max-h-64">
                {chatMessages.map((msg) => (
                  <div key={msg.id} className="bg-gray-800/50 rounded-lg p-3">
                    <div className="text-sm font-semibold text-blue-400">{msg.userName}</div>
                    <div className="text-gray-300">{msg.message}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {new Date(msg.createdAt).toLocaleTimeString()}
                    </div>
                  </div>
                ))}
                {chatMessages.length === 0 && (
                  <div className="text-center text-gray-500 py-6">
                    No messages yet. Start coordinating your hunt!
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  placeholder="Type your message..."
                  className="flex-1 bg-gray-800/50 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                />
                <Button
                  onClick={sendMessage}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>

              <Button
                onClick={leaveRoom}
                variant="outline"
                className="mt-3 border-red-500 text-red-400 hover:bg-red-900/20"
              >
                Leave Room
              </Button>
            </>
          )}
        </DialogContent>
      </Dialog>

      <LoginModal open={showLoginModal} onClose={() => setShowLoginModal(false)} />
    </div>
  );
}
