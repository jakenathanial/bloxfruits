import { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { apiCall } from '../../utils/supabase-client';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Shield, Plus, Edit, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';

interface Fruit {
  id: string;
  name: string;
  imageUrl: string;
  rarity: string;
  type: string;
  value?: number;
  description?: string;
}

export function AdminPage() {
  const { user } = useAuth();
  const [fruits, setFruits] = useState<Fruit[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingFruit, setEditingFruit] = useState<Fruit | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    imageUrl: '',
    rarity: 'Common',
    type: 'Natural',
    value: '',
    description: '',
  });

  useEffect(() => {
    if (user?.isAdmin) {
      fetchFruits();
    }
  }, [user]);

  const fetchFruits = async () => {
    try {
      const { fruits: fetchedFruits } = await apiCall('/fruits');
      setFruits(fetchedFruits);
    } catch (error) {
      console.error('Failed to fetch fruits:', error);
    }
  };

  const openEditModal = (fruit: Fruit) => {
    setEditingFruit(fruit);
    setFormData({
      name: fruit.name,
      imageUrl: fruit.imageUrl,
      rarity: fruit.rarity,
      type: fruit.type,
      value: fruit.value?.toString() || '',
      description: fruit.description || '',
    });
    setShowModal(true);
  };

  const openCreateModal = () => {
    setEditingFruit(null);
    setFormData({
      name: '',
      imageUrl: '',
      rarity: 'Common',
      type: 'Natural',
      value: '',
      description: '',
    });
    setShowModal(true);
  };

  const saveFruit = async () => {
    if (!formData.name || !formData.rarity) {
      alert('Please fill in required fields (Name and Rarity)');
      return;
    }

    try {
      const payload = {
        name: formData.name,
        imageUrl: formData.imageUrl,
        rarity: formData.rarity,
        type: formData.type,
        value: formData.value ? parseInt(formData.value) : undefined,
        description: formData.description || undefined,
      };

      if (editingFruit) {
        await apiCall(`/fruits/${editingFruit.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
      } else {
        await apiCall('/fruits', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
      }

      setShowModal(false);
      fetchFruits();
    } catch (error) {
      console.error('Failed to save fruit:', error);
      alert('Failed to save fruit. Please try again.');
    }
  };

  const deleteFruit = async (fruitId: string) => {
    if (!confirm('Are you sure you want to delete this fruit?')) return;

    try {
      await apiCall(`/fruits/${fruitId}`, { method: 'DELETE' });
      fetchFruits();
    } catch (error) {
      console.error('Failed to delete fruit:', error);
      alert('Failed to delete fruit. Please try again.');
    }
  };

  if (!user?.isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black pt-24 pb-8 px-4 flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">Admin access required</p>
        </div>
      </div>
    );
  }

  const rarities = ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary', 'Mythical'];
  const types = ['Natural', 'Elemental', 'Beast', 'Paramecia', 'Zoan', 'Logia'];

  const rarityColors: Record<string, string> = {
    Common: 'from-gray-600 to-gray-700',
    Uncommon: 'from-green-600 to-green-700',
    Rare: 'from-blue-600 to-blue-700',
    Epic: 'from-purple-600 to-purple-700',
    Legendary: 'from-yellow-600 to-orange-600',
    Mythical: 'from-red-600 to-pink-600',
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black pt-24 pb-8 px-4">
      <div className="container mx-auto max-w-7xl">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-purple-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Admin Dashboard
            </h1>
          </div>
          <Button
            onClick={openCreateModal}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold transition-all duration-300 hover:scale-105"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Fruit
          </Button>
        </div>

        <div className="bg-gradient-to-br from-gray-900/90 to-black/90 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6 mb-6">
          <h2 className="text-xl font-semibold text-white mb-4">Fruit Management</h2>
          <p className="text-gray-400">
            Manage all fruits in the database. These fruits will be available for trade creation.
          </p>
          <div className="mt-4 text-sm text-gray-500">
            Total Fruits: <span className="text-purple-400 font-semibold">{fruits.length}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {fruits.map((fruit) => (
            <motion.div
              key={fruit.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className={`bg-gradient-to-br ${
                rarityColors[fruit.rarity] || 'from-gray-700 to-gray-800'
              } rounded-xl p-4 relative group hover:scale-105 transition-all duration-300`}
            >
              <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => openEditModal(fruit)}
                  className="bg-blue-600 hover:bg-blue-700 p-2 rounded-lg transition-colors"
                >
                  <Edit className="w-4 h-4 text-white" />
                </button>
                <button
                  onClick={() => deleteFruit(fruit.id)}
                  className="bg-red-600 hover:bg-red-700 p-2 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4 text-white" />
                </button>
              </div>

              {fruit.imageUrl ? (
                <img
                  src={fruit.imageUrl}
                  alt={fruit.name}
                  className="w-full h-32 object-contain mb-3"
                />
              ) : (
                <div className="w-full h-32 bg-gray-900/50 rounded-lg mb-3 flex items-center justify-center">
                  <span className="text-gray-600">No Image</span>
                </div>
              )}

              <h3 className="text-white font-semibold text-center mb-1">{fruit.name}</h3>
              <div className="text-xs text-white/80 text-center">{fruit.rarity}</div>
              {fruit.type && (
                <div className="text-xs text-white/60 text-center mt-1">{fruit.type}</div>
              )}
            </motion.div>
          ))}
        </div>

        {fruits.length === 0 && (
          <div className="text-center text-gray-500 py-12">
            No fruits yet. Add your first fruit to get started!
          </div>
        )}
      </div>

      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="bg-black/95 border-purple-500/50 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              {editingFruit ? 'Edit Fruit' : 'Add New Fruit'}
            </DialogTitle>
          </DialogHeader>

          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="col-span-2">
              <Label className="text-gray-300 mb-2 block">Fruit Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Flame Fruit"
                className="bg-gray-800/50 border-gray-700 text-white"
              />
            </div>

            <div className="col-span-2">
              <Label className="text-gray-300 mb-2 block">Image URL</Label>
              <Input
                value={formData.imageUrl}
                onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                placeholder="https://example.com/image.png"
                className="bg-gray-800/50 border-gray-700 text-white"
              />
            </div>

            <div>
              <Label className="text-gray-300 mb-2 block">Rarity *</Label>
              <Select value={formData.rarity} onValueChange={(value) => setFormData({ ...formData, rarity: value })}>
                <SelectTrigger className="bg-gray-800/50 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-700 text-white">
                  {rarities.map((rarity) => (
                    <SelectItem key={rarity} value={rarity}>
                      {rarity}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-gray-300 mb-2 block">Type</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                <SelectTrigger className="bg-gray-800/50 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-700 text-white">
                  {types.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-gray-300 mb-2 block">Value (Optional)</Label>
              <Input
                type="number"
                value={formData.value}
                onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                placeholder="e.g., 1000000"
                className="bg-gray-800/50 border-gray-700 text-white"
              />
            </div>

            <div className="col-span-2">
              <Label className="text-gray-300 mb-2 block">Description (Optional)</Label>
              <Input
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Brief description of the fruit"
                className="bg-gray-800/50 border-gray-700 text-white"
              />
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <Button
              onClick={() => setShowModal(false)}
              variant="outline"
              className="flex-1 border-gray-600 text-gray-400 hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button
              onClick={saveFruit}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
            >
              {editingFruit ? 'Update Fruit' : 'Add Fruit'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
