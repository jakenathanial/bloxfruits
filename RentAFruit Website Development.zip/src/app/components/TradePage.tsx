import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { apiCall } from '../../utils/supabase-client';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Plus, MessageCircle, X, Trash2 } from 'lucide-react';
import { LoginModal } from './LoginModal';

interface Fruit {
  id: string;
  name: string;
  imageUrl: string;
  rarity: string;
}

interface Trade {
  id: string;
  userId: string;
  userName: string;
  offering: Fruit[];
  requesting: Fruit[];
  createdAt: string;
}

interface Message {
  id: string;
  userName: string;
  message: string;
  createdAt: string;
}

export function TradePage() {
  const { user } = useAuth();
  const [trades, setTrades] = useState<Trade[]>([]);
  const [fruits, setFruits] = useState<Fruit[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [offering, setOffering] = useState<(Fruit | null)[]>([null, null, null, null]);
  const [requesting, setRequesting] = useState<(Fruit | null)[]>([null, null, null, null]);
  const [selectingSlot, setSelectingSlot] = useState<{ type: 'offering' | 'requesting'; index: number } | null>(null);
  const [chatMessages, setChatMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    fetchTrades();
    fetchFruits();
    const interval = setInterval(fetchTrades, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selectedTrade) {
      fetchMessages();
      const interval = setInterval(fetchMessages, 3000);
      return () => clearInterval(interval);
    }
  }, [selectedTrade]);

  const fetchTrades = async () => {
    try {
      const { trades: fetchedTrades } = await apiCall('/trades');
      setTrades(fetchedTrades);
    } catch (error) {
      console.error('Failed to fetch trades:', error);
    }
  };

  const fetchFruits = async () => {
    try {
      const { fruits: fetchedFruits } = await apiCall('/fruits');
      setFruits(fetchedFruits);
    } catch (error) {
      console.error('Failed to fetch fruits:', error);
    }
  };

  const fetchMessages = async () => {
    if (!selectedTrade) return;
    try {
      const { messages } = await apiCall(`/trades/${selectedTrade.id}/messages`);
      setChatMessages(messages);
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    }
  };

  const createTrade = async () => {
    if (!user) {
      setShowLoginModal(true);
      return;
    }

    const offeringFruits = offering.filter((f): f is Fruit => f !== null);
    const requestingFruits = requesting.filter((f): f is Fruit => f !== null);

    if (offeringFruits.length === 0 || requestingFruits.length === 0) {
      alert('Please add at least one fruit to offer and request');
      return;
    }

    try {
      await apiCall('/trades', {
        method: 'POST',
        body: JSON.stringify({
          offering: offeringFruits,
          requesting: requestingFruits,
        }),
      });
      setShowCreateModal(false);
      setOffering([null, null, null, null]);
      setRequesting([null, null, null, null]);
      fetchTrades();
    } catch (error) {
      console.error('Failed to create trade:', error);
      alert('Failed to create trade. Please try again.');
    }
  };

  const sendMessage = async () => {
    if (!user) {
      setShowLoginModal(true);
      return;
    }
    if (!selectedTrade || !newMessage.trim()) return;

    try {
      await apiCall(`/trades/${selectedTrade.id}/messages`, {
        method: 'POST',
        body: JSON.stringify({ message: newMessage }),
      });
      setNewMessage('');
      fetchMessages();
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const deleteTrade = async (tradeId: string) => {
    if (!user) return;
    if (!confirm('Are you sure you want to delete this trade?')) return;

    try {
      await apiCall(`/trades/${tradeId}`, { method: 'DELETE' });
      fetchTrades();
      if (selectedTrade?.id === tradeId) {
        setSelectedTrade(null);
      }
    } catch (error) {
      console.error('Failed to delete trade:', error);
      alert('Failed to delete trade. Please try again.');
    }
  };

  const selectFruit = (fruit: Fruit) => {
    if (!selectingSlot) return;
    const { type, index } = selectingSlot;
    if (type === 'offering') {
      const newOffering = [...offering];
      newOffering[index] = fruit;
      setOffering(newOffering);
    } else {
      const newRequesting = [...requesting];
      newRequesting[index] = fruit;
      setRequesting(newRequesting);
    }
    setSelectingSlot(null);
  };

  const rarityColors: Record<string, string> = {
    Common: 'from-gray-600 to-gray-700',
    Uncommon: 'from-green-600 to-green-700',
    Rare: 'from-blue-600 to-blue-700',
    Epic: 'from-purple-600 to-purple-700',
    Legendary: 'from-yellow-600 to-orange-600',
    Mythical: 'from-red-600 to-pink-600',
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black pt-24 pb-8 px-4">
      <div className="container mx-auto max-w-7xl">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
            Trade Market
          </h1>
          <Button
            onClick={() => user ? setShowCreateModal(true) : setShowLoginModal(true)}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold transition-all duration-300 hover:scale-105"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Trade
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trades.map((trade) => (
            <motion.div
              key={trade.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-gradient-to-br from-gray-900/90 to-black/90 backdrop-blur-sm border border-purple-500/30 rounded-xl p-4 hover:border-purple-500/60 transition-all duration-300"
            >
              <div className="text-sm text-gray-400 mb-3 flex items-center justify-between">
                <span>{trade.userName}</span>
                {(user?.id === trade.userId || user?.isAdmin) && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-400 hover:text-red-300 h-6 w-6 p-0"
                    onClick={() => deleteTrade(trade.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="text-xs text-gray-500 mb-2">Offering</div>
                  <div className="grid grid-cols-2 gap-2">
                    {trade.offering.map((fruit, idx) => (
                      <div
                        key={idx}
                        className={`aspect-square rounded-lg bg-gradient-to-br ${
                          rarityColors[fruit.rarity] || 'from-gray-700 to-gray-800'
                        } p-2 flex flex-col items-center justify-center`}
                      >
                        {fruit.imageUrl && (
                          <img src={fruit.imageUrl} alt={fruit.name} className="w-full h-full object-contain mb-1" />
                        )}
                        <span className="text-[10px] text-white text-center leading-tight">{fruit.name}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-gray-500 mb-2">Requesting</div>
                  <div className="grid grid-cols-2 gap-2">
                    {trade.requesting.map((fruit, idx) => (
                      <div
                        key={idx}
                        className={`aspect-square rounded-lg bg-gradient-to-br ${
                          rarityColors[fruit.rarity] || 'from-gray-700 to-gray-800'
                        } p-2 flex flex-col items-center justify-center`}
                      >
                        {fruit.imageUrl && (
                          <img src={fruit.imageUrl} alt={fruit.name} className="w-full h-full object-contain mb-1" />
                        )}
                        <span className="text-[10px] text-white text-center leading-tight">{fruit.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <Button
                onClick={() => setSelectedTrade(trade)}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Open Trade Chat
              </Button>
            </motion.div>
          ))}
        </div>

        {trades.length === 0 && (
          <div className="text-center text-gray-500 py-12">
            No trades available. Be the first to create one!
          </div>
        )}
      </div>

      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="bg-black/95 border-purple-500/50 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Create Trade
            </DialogTitle>
          </DialogHeader>

          <div className="grid grid-cols-2 gap-6 mt-4">
            <div>
              <h3 className="text-lg font-semibold mb-3 text-purple-400">Offering</h3>
              <div className="grid grid-cols-2 gap-3">
                {offering.map((fruit, idx) => (
                  <div
                    key={idx}
                    onClick={() => setSelectingSlot({ type: 'offering', index: idx })}
                    className="aspect-square rounded-lg bg-gray-800/50 border-2 border-dashed border-gray-600 hover:border-purple-500 cursor-pointer flex flex-col items-center justify-center transition-all"
                  >
                    {fruit ? (
                      <>
                        {fruit.imageUrl && <img src={fruit.imageUrl} alt={fruit.name} className="w-full h-3/4 object-contain" />}
                        <span className="text-xs text-white mt-1">{fruit.name}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            const newOffering = [...offering];
                            newOffering[idx] = null;
                            setOffering(newOffering);
                          }}
                          className="text-red-400 hover:text-red-300 mt-1"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <Plus className="w-8 h-8 text-gray-600" />
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-3 text-blue-400">Requesting</h3>
              <div className="grid grid-cols-2 gap-3">
                {requesting.map((fruit, idx) => (
                  <div
                    key={idx}
                    onClick={() => setSelectingSlot({ type: 'requesting', index: idx })}
                    className="aspect-square rounded-lg bg-gray-800/50 border-2 border-dashed border-gray-600 hover:border-blue-500 cursor-pointer flex flex-col items-center justify-center transition-all"
                  >
                    {fruit ? (
                      <>
                        {fruit.imageUrl && <img src={fruit.imageUrl} alt={fruit.name} className="w-full h-3/4 object-contain" />}
                        <span className="text-xs text-white mt-1">{fruit.name}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            const newRequesting = [...requesting];
                            newRequesting[idx] = null;
                            setRequesting(newRequesting);
                          }}
                          className="text-red-400 hover:text-red-300 mt-1"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <Plus className="w-8 h-8 text-gray-600" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {selectingSlot && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-3">Select Fruit</h3>
              <div className="grid grid-cols-3 md:grid-cols-4 gap-3 max-h-60 overflow-y-auto">
                {fruits.map((fruit) => (
                  <div
                    key={fruit.id}
                    onClick={() => selectFruit(fruit)}
                    className={`p-3 rounded-lg bg-gradient-to-br ${
                      rarityColors[fruit.rarity] || 'from-gray-700 to-gray-800'
                    } cursor-pointer hover:scale-105 transition-all flex flex-col items-center`}
                  >
                    {fruit.imageUrl && <img src={fruit.imageUrl} alt={fruit.name} className="w-full h-16 object-contain mb-2" />}
                    <span className="text-xs text-white text-center">{fruit.name}</span>
                    <span className="text-[10px] text-gray-300">{fruit.rarity}</span>
                  </div>
                ))}
              </div>
              {fruits.length === 0 && (
                <div className="text-center text-gray-500 py-6">
                  No fruits available. Admin needs to add fruits first.
                </div>
              )}
            </div>
          )}

          <div className="flex gap-3 mt-6">
            <Button
              onClick={() => setShowCreateModal(false)}
              variant="outline"
              className="flex-1 border-gray-600 text-gray-400 hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button
              onClick={createTrade}
              className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
            >
              Publish Trade
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!selectedTrade} onOpenChange={() => setSelectedTrade(null)}>
        <DialogContent className="bg-black/95 border-purple-500/50 text-white max-w-2xl max-h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Trade Chat - {selectedTrade?.userName}</DialogTitle>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto space-y-3 mb-4 max-h-96">
            {chatMessages.map((msg) => (
              <div key={msg.id} className="bg-gray-800/50 rounded-lg p-3">
                <div className="text-sm font-semibold text-purple-400">{msg.userName}</div>
                <div className="text-gray-300">{msg.message}</div>
                <div className="text-xs text-gray-500 mt-1">
                  {new Date(msg.createdAt).toLocaleTimeString()}
                </div>
              </div>
            ))}
            {chatMessages.length === 0 && (
              <div className="text-center text-gray-500 py-6">
                No messages yet. Start the conversation!
              </div>
            )}
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Type your message..."
              className="flex-1 bg-gray-800/50 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
            />
            <Button
              onClick={sendMessage}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
            >
              Send
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <LoginModal open={showLoginModal} onClose={() => setShowLoginModal(false)} />
    </div>
  );
}
