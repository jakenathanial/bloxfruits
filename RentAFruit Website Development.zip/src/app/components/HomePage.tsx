import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { apiCall } from '../../utils/supabase-client';
import { ShoppingBag, Waves, Users, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const [stats, setStats] = useState({
    activeTrades: 0,
    activeRooms: 0,
    totalUsers: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const { stats: fetchedStats } = await apiCall('/stats');
        setStats(fetchedStats);
      } catch (error) {
        console.error('Failed to fetch stats:', error);
      }
    };

    fetchStats();
    const interval = setInterval(fetchStats, 10000);
    return () => clearInterval(interval);
  }, []);

  const statCards = [
    { label: 'Active Trades', value: stats.activeTrades, icon: ShoppingBag, color: 'from-purple-600 to-purple-400' },
    { label: 'Active Hunt Rooms', value: stats.activeRooms, icon: Waves, color: 'from-blue-600 to-blue-400' },
    { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'from-pink-600 to-pink-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black pt-20 pb-8 px-4">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-6xl md:text-8xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-blue-400 to-purple-400 bg-clip-text text-transparent animate-gradient">
            RentAFruit
          </h1>
          <p className="text-xl md:text-2xl text-gray-400 mb-2">Trade. Hunt. Rise.</p>
          <p className="text-gray-500">The ultimate platform for Roblox Blox Fruits players</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12"
        >
          {statCards.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
              className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6 hover:border-purple-500/60 transition-all duration-300 hover:scale-105"
            >
              <div className={`inline-flex p-3 rounded-lg bg-gradient-to-br ${stat.color} mb-4`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-gray-400 text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          <div className="bg-gradient-to-br from-purple-900/40 to-purple-700/20 backdrop-blur-sm border border-purple-500/50 rounded-xl p-8 hover:border-purple-500/80 transition-all duration-300 hover:scale-105">
            <ShoppingBag className="w-12 h-12 text-purple-400 mb-4" />
            <h2 className="text-2xl font-bold text-white mb-3">Trade Fruits</h2>
            <p className="text-gray-300 mb-6">
              Create and browse fruit trades with other players. Find the perfect deal for your collection.
            </p>
            <Button
              onClick={() => onNavigate('trade')}
              className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 text-white font-semibold py-6 transition-all duration-300"
            >
              Start Trading
            </Button>
          </div>

          <div className="bg-gradient-to-br from-blue-900/40 to-blue-700/20 backdrop-blur-sm border border-blue-500/50 rounded-xl p-8 hover:border-blue-500/80 transition-all duration-300 hover:scale-105">
            <Waves className="w-12 h-12 text-blue-400 mb-4" />
            <h2 className="text-2xl font-bold text-white mb-3">Leviathan Hunt</h2>
            <p className="text-gray-300 mb-6">
              Join or create hunt rooms to team up with players. Coordinate your Leviathan raids.
            </p>
            <Button
              onClick={() => onNavigate('hunt')}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white font-semibold py-6 transition-all duration-300"
            >
              Join Hunt
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="mt-12 text-center"
        >
          <div className="inline-flex items-center gap-2 text-gray-500 text-sm">
            <TrendingUp className="w-4 h-4" />
            <span>Live stats update every 10 seconds</span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
