import { useState } from 'react';
import { AuthProvider } from '../contexts/AuthContext';
import { Navigation } from './components/Navigation';
import { HomePage } from './components/HomePage';
import { TradePage } from './components/TradePage';
import { HuntPage } from './components/HuntPage';
import { ProfilePage } from './components/ProfilePage';
import { AdminPage } from './components/AdminPage';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'trade':
        return <TradePage />;
      case 'hunt':
        return <HuntPage />;
      case 'profile':
        return <ProfilePage />;
      case 'admin':
        return <AdminPage />;
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <AuthProvider>
      <div className="min-h-screen bg-black text-white">
        <Navigation currentPage={currentPage} onNavigate={setCurrentPage} />
        {renderPage()}
        <Toaster />
      </div>
    </AuthProvider>
  );
}