import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2.49.8";
import * as kv from "./kv_store.tsx";

const app = new Hono();

app.use('*', logger(console.log));

app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

const supabaseAdmin = () => createClient(
  Deno.env.get('SUPABASE_URL'),
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'),
);

const supabaseClient = () => createClient(
  Deno.env.get('SUPABASE_URL'),
  Deno.env.get('SUPABASE_ANON_KEY'),
);

async function getUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken || accessToken === Deno.env.get('SUPABASE_ANON_KEY')) {
    return null;
  }
  const { data: { user }, error } = await supabaseAdmin().auth.getUser(accessToken);
  if (error || !user) {
    return null;
  }
  return user;
}

app.get("/make-server-75b8ebf1/health", (c) => {
  return c.json({ status: "ok" });
});

// AUTH ENDPOINTS
app.post("/make-server-75b8ebf1/auth/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    const { data, error } = await supabaseAdmin().auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });
    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email,
      name,
      hasFastBoat: false,
      hasBeastHunterBoat: false,
      isAdmin: false,
      createdAt: new Date().toISOString()
    });
    return c.json({ user: data.user });
  } catch (error) {
    console.log('Signup error:', error);
    return c.json({ error: 'Signup failed: ' + error.message }, 500);
  }
});

app.get("/make-server-75b8ebf1/auth/session", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ user: null });
    }
    const userData = await kv.get(`user:${user.id}`);
    return c.json({ user: userData || { id: user.id, email: user.email, name: user.user_metadata?.name } });
  } catch (error) {
    console.log('Session error:', error);
    return c.json({ error: 'Session check failed: ' + error.message }, 500);
  }
});

// USER PROFILE ENDPOINTS
app.get("/make-server-75b8ebf1/profile/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const userData = await kv.get(`user:${userId}`);
    if (!userData) {
      return c.json({ error: 'User not found' }, 404);
    }
    return c.json({ profile: userData });
  } catch (error) {
    console.log('Get profile error:', error);
    return c.json({ error: 'Failed to get profile: ' + error.message }, 500);
  }
});

app.put("/make-server-75b8ebf1/profile", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    const { name, hasFastBoat, hasBeastHunterBoat, avatarUrl } = await c.req.json();
    const existingUser = await kv.get(`user:${user.id}`);
    const updatedUser = {
      ...existingUser,
      name: name || existingUser.name,
      hasFastBoat: hasFastBoat !== undefined ? hasFastBoat : existingUser.hasFastBoat,
      hasBeastHunterBoat: hasBeastHunterBoat !== undefined ? hasBeastHunterBoat : existingUser.hasBeastHunterBoat,
      avatarUrl: avatarUrl !== undefined ? avatarUrl : existingUser.avatarUrl,
    };
    await kv.set(`user:${user.id}`, updatedUser);
    return c.json({ profile: updatedUser });
  } catch (error) {
    console.log('Update profile error:', error);
    return c.json({ error: 'Failed to update profile: ' + error.message }, 500);
  }
});

// FRUIT ENDPOINTS (ADMIN)
app.post("/make-server-75b8ebf1/fruits", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    const userData = await kv.get(`user:${user.id}`);
    if (!userData?.isAdmin) {
      return c.json({ error: 'Admin access required' }, 403);
    }
    const { name, imageUrl, rarity, type, value, description } = await c.req.json();
    const fruitId = crypto.randomUUID();
    const fruit = {
      id: fruitId,
      name,
      imageUrl,
      rarity,
      type,
      value,
      description,
      createdAt: new Date().toISOString()
    };
    await kv.set(`fruit:${fruitId}`, fruit);
    return c.json({ fruit });
  } catch (error) {
    console.log('Create fruit error:', error);
    return c.json({ error: 'Failed to create fruit: ' + error.message }, 500);
  }
});

app.get("/make-server-75b8ebf1/fruits", async (c) => {
  try {
    const fruits = await kv.getByPrefix('fruit:');
    return c.json({ fruits });
  } catch (error) {
    console.log('Get fruits error:', error);
    return c.json({ error: 'Failed to get fruits: ' + error.message }, 500);
  }
});

app.put("/make-server-75b8ebf1/fruits/:fruitId", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    const userData = await kv.get(`user:${user.id}`);
    if (!userData?.isAdmin) {
      return c.json({ error: 'Admin access required' }, 403);
    }
    const fruitId = c.req.param('fruitId');
    const updates = await c.req.json();
    const existing = await kv.get(`fruit:${fruitId}`);
    if (!existing) {
      return c.json({ error: 'Fruit not found' }, 404);
    }
    const updated = { ...existing, ...updates };
    await kv.set(`fruit:${fruitId}`, updated);
    return c.json({ fruit: updated });
  } catch (error) {
    console.log('Update fruit error:', error);
    return c.json({ error: 'Failed to update fruit: ' + error.message }, 500);
  }
});

app.delete("/make-server-75b8ebf1/fruits/:fruitId", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    const userData = await kv.get(`user:${user.id}`);
    if (!userData?.isAdmin) {
      return c.json({ error: 'Admin access required' }, 403);
    }
    const fruitId = c.req.param('fruitId');
    await kv.del(`fruit:${fruitId}`);
    return c.json({ success: true });
  } catch (error) {
    console.log('Delete fruit error:', error);
    return c.json({ error: 'Failed to delete fruit: ' + error.message }, 500);
  }
});

// TRADE ENDPOINTS
app.post("/make-server-75b8ebf1/trades", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized - Login required to create trades' }, 401);
    }
    const { offering, requesting } = await c.req.json();
    const tradeId = crypto.randomUUID();
    const userData = await kv.get(`user:${user.id}`);
    const trade = {
      id: tradeId,
      userId: user.id,
      userName: userData?.name || 'Anonymous',
      offering,
      requesting,
      createdAt: new Date().toISOString()
    };
    await kv.set(`trade:${tradeId}`, trade);
    return c.json({ trade });
  } catch (error) {
    console.log('Create trade error:', error);
    return c.json({ error: 'Failed to create trade: ' + error.message }, 500);
  }
});

app.get("/make-server-75b8ebf1/trades", async (c) => {
  try {
    const trades = await kv.getByPrefix('trade:');
    return c.json({ trades: trades.sort((a: any, b: any) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    )});
  } catch (error) {
    console.log('Get trades error:', error);
    return c.json({ error: 'Failed to get trades: ' + error.message }, 500);
  }
});

app.get("/make-server-75b8ebf1/trades/:tradeId", async (c) => {
  try {
    const tradeId = c.req.param('tradeId');
    const trade = await kv.get(`trade:${tradeId}`);
    if (!trade) {
      return c.json({ error: 'Trade not found' }, 404);
    }
    return c.json({ trade });
  } catch (error) {
    console.log('Get trade error:', error);
    return c.json({ error: 'Failed to get trade: ' + error.message }, 500);
  }
});

app.delete("/make-server-75b8ebf1/trades/:tradeId", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    const tradeId = c.req.param('tradeId');
    const trade = await kv.get(`trade:${tradeId}`);
    const userData = await kv.get(`user:${user.id}`);
    if (!trade) {
      return c.json({ error: 'Trade not found' }, 404);
    }
    if (trade.userId !== user.id && !userData?.isAdmin) {
      return c.json({ error: 'Unauthorized - Can only delete your own trades' }, 403);
    }
    await kv.del(`trade:${tradeId}`);
    const messages = await kv.getByPrefix(`trade-chat:${tradeId}:`);
    for (const msg of messages) {
      await kv.del(`trade-chat:${tradeId}:${msg.id}`);
    }
    return c.json({ success: true });
  } catch (error) {
    console.log('Delete trade error:', error);
    return c.json({ error: 'Failed to delete trade: ' + error.message }, 500);
  }
});

// TRADE CHAT ENDPOINTS
app.post("/make-server-75b8ebf1/trades/:tradeId/messages", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized - Login required to chat' }, 401);
    }
    const tradeId = c.req.param('tradeId');
    const { message } = await c.req.json();
    const messageId = crypto.randomUUID();
    const userData = await kv.get(`user:${user.id}`);
    const chatMessage = {
      id: messageId,
      tradeId,
      userId: user.id,
      userName: userData?.name || 'Anonymous',
      message,
      createdAt: new Date().toISOString()
    };
    await kv.set(`trade-chat:${tradeId}:${messageId}`, chatMessage);
    return c.json({ message: chatMessage });
  } catch (error) {
    console.log('Send trade message error:', error);
    return c.json({ error: 'Failed to send message: ' + error.message }, 500);
  }
});

app.get("/make-server-75b8ebf1/trades/:tradeId/messages", async (c) => {
  try {
    const tradeId = c.req.param('tradeId');
    const messages = await kv.getByPrefix(`trade-chat:${tradeId}:`);
    return c.json({ messages: messages.sort((a: any, b: any) =>
      new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    )});
  } catch (error) {
    console.log('Get trade messages error:', error);
    return c.json({ error: 'Failed to get messages: ' + error.message }, 500);
  }
});

// LEVIATHAN ROOM ENDPOINTS
app.post("/make-server-75b8ebf1/rooms", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized - Login required to create rooms' }, 401);
    }
    const { destination, robloxUsername, maxPlayers = 7 } = await c.req.json();
    const roomId = crypto.randomUUID();
    const userData = await kv.get(`user:${user.id}`);
    const room = {
      id: roomId,
      destination,
      hostId: user.id,
      hostName: userData?.name || 'Anonymous',
      players: [{
        userId: user.id,
        userName: userData?.name || 'Anonymous',
        robloxUsername,
        hasFastBoat: userData?.hasFastBoat || false,
        hasBeastHunterBoat: userData?.hasBeastHunterBoat || false,
      }],
      maxPlayers,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString()
    };
    await kv.set(`room:${roomId}`, room);
    return c.json({ room });
  } catch (error) {
    console.log('Create room error:', error);
    return c.json({ error: 'Failed to create room: ' + error.message }, 500);
  }
});

app.get("/make-server-75b8ebf1/rooms", async (c) => {
  try {
    const destination = c.req.query('destination');
    let rooms = await kv.getByPrefix('room:');
    const now = new Date();
    rooms = rooms.filter((room: any) => new Date(room.expiresAt) > now);
    if (destination) {
      rooms = rooms.filter((room: any) => room.destination === destination);
    }
    for (const room of rooms) {
      if (room.players.length === 0 || new Date(room.expiresAt) <= now) {
        await kv.del(`room:${room.id}`);
      }
    }
    rooms = rooms.filter((room: any) => room.players.length > 0);
    return c.json({ rooms: rooms.sort((a: any, b: any) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    )});
  } catch (error) {
    console.log('Get rooms error:', error);
    return c.json({ error: 'Failed to get rooms: ' + error.message }, 500);
  }
});

app.get("/make-server-75b8ebf1/rooms/:roomId", async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const room = await kv.get(`room:${roomId}`);
    if (!room) {
      return c.json({ error: 'Room not found' }, 404);
    }
    return c.json({ room });
  } catch (error) {
    console.log('Get room error:', error);
    return c.json({ error: 'Failed to get room: ' + error.message }, 500);
  }
});

app.post("/make-server-75b8ebf1/rooms/:roomId/join", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized - Login required to join rooms' }, 401);
    }
    const roomId = c.req.param('roomId');
    const { robloxUsername } = await c.req.json();
    const room = await kv.get(`room:${roomId}`);
    if (!room) {
      return c.json({ error: 'Room not found' }, 404);
    }
    if (room.players.length >= room.maxPlayers) {
      return c.json({ error: 'Room is full' }, 400);
    }
    if (room.players.some((p: any) => p.userId === user.id)) {
      return c.json({ error: 'Already in room' }, 400);
    }
    const userData = await kv.get(`user:${user.id}`);
    room.players.push({
      userId: user.id,
      userName: userData?.name || 'Anonymous',
      robloxUsername,
      hasFastBoat: userData?.hasFastBoat || false,
      hasBeastHunterBoat: userData?.hasBeastHunterBoat || false,
    });
    await kv.set(`room:${roomId}`, room);
    return c.json({ room });
  } catch (error) {
    console.log('Join room error:', error);
    return c.json({ error: 'Failed to join room: ' + error.message }, 500);
  }
});

app.post("/make-server-75b8ebf1/rooms/:roomId/leave", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    const roomId = c.req.param('roomId');
    const room = await kv.get(`room:${roomId}`);
    if (!room) {
      return c.json({ error: 'Room not found' }, 404);
    }
    room.players = room.players.filter((p: any) => p.userId !== user.id);
    if (room.players.length === 0) {
      await kv.del(`room:${roomId}`);
    } else {
      await kv.set(`room:${roomId}`, room);
    }
    return c.json({ success: true });
  } catch (error) {
    console.log('Leave room error:', error);
    return c.json({ error: 'Failed to leave room: ' + error.message }, 500);
  }
});

// ROOM CHAT ENDPOINTS
app.post("/make-server-75b8ebf1/rooms/:roomId/messages", async (c) => {
  try {
    const user = await getUser(c.req.raw);
    if (!user) {
      return c.json({ error: 'Unauthorized - Login required to chat' }, 401);
    }
    const roomId = c.req.param('roomId');
    const { message } = await c.req.json();
    const room = await kv.get(`room:${roomId}`);
    if (!room) {
      return c.json({ error: 'Room not found' }, 404);
    }
    if (!room.players.some((p: any) => p.userId === user.id)) {
      return c.json({ error: 'Must join room to chat' }, 403);
    }
    const messageId = crypto.randomUUID();
    const userData = await kv.get(`user:${user.id}`);
    const chatMessage = {
      id: messageId,
      roomId,
      userId: user.id,
      userName: userData?.name || 'Anonymous',
      message,
      createdAt: new Date().toISOString()
    };
    await kv.set(`room-chat:${roomId}:${messageId}`, chatMessage);
    return c.json({ message: chatMessage });
  } catch (error) {
    console.log('Send room message error:', error);
    return c.json({ error: 'Failed to send message: ' + error.message }, 500);
  }
});

app.get("/make-server-75b8ebf1/rooms/:roomId/messages", async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const messages = await kv.getByPrefix(`room-chat:${roomId}:`);
    return c.json({ messages: messages.sort((a: any, b: any) =>
      new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    )});
  } catch (error) {
    console.log('Get room messages error:', error);
    return c.json({ error: 'Failed to get messages: ' + error.message }, 500);
  }
});

// STATS ENDPOINT
app.get("/make-server-75b8ebf1/stats", async (c) => {
  try {
    const trades = await kv.getByPrefix('trade:');
    const rooms = await kv.getByPrefix('room:');
    const users = await kv.getByPrefix('user:');
    const now = new Date();
    const activeRooms = rooms.filter((room: any) =>
      new Date(room.expiresAt) > now && room.players.length > 0
    );
    return c.json({
      stats: {
        activeTrades: trades.length,
        activeRooms: activeRooms.length,
        totalUsers: users.length
      }
    });
  } catch (error) {
    console.log('Get stats error:', error);
    return c.json({ error: 'Failed to get stats: ' + error.message }, 500);
  }
});

Deno.serve(app.fetch);